class Hparams:
    class Audio:
        num_mels = 80           # Mel谱频率带数量/特征参数维度
        ppg_dim = 351           # PPG（语音后验概率图）特征维度
        bn_dim = 256            # 瓶颈层特征维度
        num_freq = 1025         # 线性谱频率带数量/特征参数维度
        min_mel_freq = 30.      # 最低Mel频率
        max_mel_freq = 7600.    # 最高Mel频率
        sample_rate = 16000     # 采样率
        frame_length_ms = 25    # 每帧音频的时间长度
        frame_shift_ms = 10     # 连续帧之间的间隔
        upper_f0 = 500.         # 基本频率（F0）的上限
        lower_f0 = 30.          # 基本频率（F0）的下限
        n_mfcc = 13             # 提取的 MFCC（梅尔频率倒谱系数）特征的数量
        preemphasize = 0.97     # 预加重系数：用于强调音频信号中的高频成分
        min_level_db = -80.0    # 频谱图的最小值
        ref_level_db = 20.0     # 频谱图归一化的参考值
        max_abs_value = 1.      # 归一化频谱图允许的最大绝对值
        symmetric_specs = False # 是否使用围绕0对称的频谱图值
        griffin_lim_iters = 60  # Griffin-Lim 算法的迭代次数（用于波形重建）
        power = 1.5             # 频谱图的幂次方
        center = True           # 是否对音频帧进行居中处理

    class SPEAKERS:
        num_spk = 3
        spk_to_inds = ['bzn', 'mst-female', 'mst-male']

    class TrainToOne:
        dev_set_rate = 0.1
        test_set_rate = 0.05
        epochs = 60
        train_batch_size = 32
        test_batch_size = 1
        shuffle_buffer = 128
        shuffle = True
        learning_rate = 1e-3
        num_workers = 16

    class TrainToMany:
        dev_set_rate = 0.1
        test_set_rate = 0.05
        epochs = 60
        train_batch_size = 32
        test_batch_size = 1
        shuffle_buffer = 128
        shuffle = True
        learning_rate = 1e-3
        num_workers = 16

    class BLSTMConversionModel:
        lstm_hidden = 256

    class BLSTMToManyConversionModel:
        lstm_hidden = 256
        spk_embd_dim = 64
