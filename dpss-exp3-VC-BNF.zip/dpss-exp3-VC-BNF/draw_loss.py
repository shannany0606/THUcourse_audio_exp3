import re
import matplotlib.pyplot as plt

def parse_loss_data(filename):
    """
    Parse the log file and extract training loss values
    
    Args:
        filename (str): Path to the log file
    
    Returns:
        tuple: Two lists containing epoch numbers and loss values
    """
    epochs = []
    losses = []
    sum=0

    with open(filename, 'r', encoding='utf-8') as file:
        for line in file:
            # Match training loss lines
            match = re.search(r'\[(\d+),\s*(\d+)\] Training loss: (\d+\.\d+)', line)
            if match:
                epoch = int(match.group(1))
                batch = int(match.group(2))
                loss = float(match.group(3))
                
                # Use batch number as x-axis to show detailed loss progression
                epochs.append((epoch - 1) * 169 + batch)
                losses.append(loss)
                if epoch==60:sum+=loss
    
    print(sum/169)
    return epochs, losses

def plot_loss_curve(filename):
    """
    Plot the training loss curve from the log file
    
    Args:
        filename (str): Path to the log file
    """
    # Parse loss data
    epochs, losses = parse_loss_data(filename)
    
    # Create the plot
    plt.figure(figsize=(12, 6))
    plt.plot(epochs, losses, marker='o', linestyle='-', markersize=3)
    plt.title('Training Loss Curve', fontsize=15)
    plt.xlabel('Batch Number', fontsize=12)
    plt.ylabel('Training Loss', fontsize=12)
    plt.grid(True, linestyle='--', alpha=0.7)
    
    # Add some annotations
    plt.tight_layout()
    
    # Save the plot
    plt.savefig('training_loss_curve_4.png', dpi=300)
    
    # Optionally show the plot
    plt.show()

# Usage
plot_loss_curve('run_4.log')